package es.jacaranda.enumerados;

public interface ordenable {

}
