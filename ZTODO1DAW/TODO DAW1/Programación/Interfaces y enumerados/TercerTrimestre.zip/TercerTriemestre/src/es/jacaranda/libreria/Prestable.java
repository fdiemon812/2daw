package es.jacaranda.libreria;

public interface Prestable {

	void prestar();
	void devolver();
	boolean prestado();
}
