
ordenar = document.getElementById('ordenar')


ordenar.addEventListener('click', ordena)

function ordena(){
    numeros = document.getElementById('numeros')
    ordenados = document.getElementById('ordenado')
    valores = numeros.value.split(',')
    ordenados.textContent = valores.sort(function ordena(a,b){ return a - b;})
}