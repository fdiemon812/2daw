enlaces = document.getElementsByTagName('a');
for (i=0;i<enlaces.length;i++){
    enlaces[i].addEventListener('click',cambiar)
}

function cambiar(event){
    enlace = event.currentTarget;
    div = enlace.parentElement;
    parrafo = div.children[0];
    //parrafo = div.getElementsByTagName('p');
    //parrafo = enlace.parentElement.getElementsByTagName('p')[0];
    //parrafo = enlace.previousElementSibling;
    
    if (parrafo.hidden){
        parrafo.hidden = false;
        enlace.textContent = 'Ocultar contenido'
    }
    else{
        parrafo.hidden = true;
        enlace.textContent = 'Mostrar contenido'
    }
}