enlaces = document.getElementsByTagName('a');
enlaces[0].addEventListener('click',cambiar1)
enlaces[1].addEventListener('click',cambiar2)
enlaces[2].addEventListener('click',cambiar3)


function cambiar1(){
    enlace = document.getElementsByClassName('uno')[1]
    parrafo = document.getElementsByClassName('uno')[0]
    cambiar(enlace,parrafo)

}
function cambiar2(){
    enlace = document.getElementsByClassName('dos')[1]
    parrafo = document.getElementsByClassName('dos')[0]
    cambiar(enlace,parrafo)

}
function cambiar3(){
    enlace = document.getElementsByClassName('tres')[1]
    parrafo = document.getElementsByClassName('tres')[0]
    cambiar(enlace,parrafo)

}

function cambiar(enlace, parrafo){
    //console.log(parrafo)
    if (parrafo.getAttribute('hidden') == ''){
        parrafo.removeAttribute('hidden')
        enlace.textContent = "Ocultar contenido"
    }
    else{
        parrafo.setAttribute('hidden','');
        enlace.textContent = "Mostrar contenido"
    }
}

