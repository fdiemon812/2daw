
document.getElementsByClassName("enlace")[0].addEventListener('click',mostrar);
// enlace = document.getElementsByClassName("enlace")[0];
// enlace.addEventListener('click', mostrar)
function mostrar(){
    oculto = document.getElementsByClassName('adicional')[0];
    oculto.classList.replace('oculto','visible')
    //e.currentTarget.classList.add('oculto')
    document.getElementsByClassName('enlace')[0].classList.add('oculto')
}