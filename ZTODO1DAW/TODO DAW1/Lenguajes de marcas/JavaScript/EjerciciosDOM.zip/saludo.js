nombre = document.getElementById('nombre');
apellidos = document.getElementById('apellidos');
boton = document.getElementById('saludar');
div = document.getElementById('saludo');

boton.addEventListener('click',saludar);

function saludar(){
    div.textContent = "Hola " + nombre.value + " " + apellidos.value + " bienvenido a esta página."
}
