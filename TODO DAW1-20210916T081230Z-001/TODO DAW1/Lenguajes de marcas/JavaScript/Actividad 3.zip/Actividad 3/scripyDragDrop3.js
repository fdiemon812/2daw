const pendingTasks = document.getElementById('pending-tasks')
const finishedTasks = document.getElementById('finished-tasks')
const doingTasks = document.getElementById('doing-tasks')

//dataTransfer
//setData: Establece la información que queremos compartir
//getData: Establece la información que queremos obtener

pendingTasks.addEventListener('dragstart', (e) => {
    console.log(e.dataTransfer)
    e.dataTransfer.setData('text/plain', e.target.id)
    console.log(e.dataTransfer.getData)
})

pendingTasks.addEventListener('drag', (e) => {
    e.target.classList.add('active')
})


pendingTasks.addEventListener('dragend', (e) => {
    e.target.classList.remove('active')
})

doingTasks.addEventListener('dragstart', (e) => {
    console.log(e.dataTransfer)
    e.dataTransfer.setData('text/plain', e.target.id)
    console.log(e.dataTransfer.getData)
})

doingTasks.addEventListener('drag', (e) => {
    e.target.classList.add('active')
})

doingTasks.addEventListener('dragend', (e) => {
    e.target.classList.remove('active')
})

pendingTasks.addEventListener('drag', (e) => {
    e.target.classList.add('active')
})

pendingTasks.addEventListener('dragend', (e) => {
    e.target.classList.remove('active')
})

//OBLIGATORIO, SI NO, NO FUNCIONA
finishedTasks.addEventListener('dragover', (e) => {
    e.preventDefault()
})

pendingTasks.addEventListener('dragover', (e) => {
    e.preventDefault()
})

finishedTasks.addEventListener('drop', (e) => {
    e.preventDefault()
    const element = document.getElementById(e.dataTransfer.getData('text'))
    element.classList.remove('active')
    const padre = element.parentNode.id
    
    switch (padre) {
        case 'pending-tasks':
          console.log('pendingTasks');
          finishedTasks.appendChild(pendingTasks.removeChild(element));
          break;
        case 'doing-tasks':
          console.log('doingTasks');
          finishedTasks.appendChild(doingTasks.removeChild(element));
          break;
      }
      ordenarFinishedTasks();
    })

doingTasks.addEventListener('dragover', (e) => {
    e.preventDefault()
})

doingTasks.addEventListener('drop', (e) => {
    e.preventDefault()
    const element = document.getElementById(e.dataTransfer.getData('text'))
    element.classList.remove('active')
    const padre = element.parentNode.id
    switch (padre) {
        case 'pending-tasks':
          console.log('pendingTasks');
          doingTasks.appendChild(pendingTasks.removeChild(element))  
          break;
        case 'finished-tasks':
          console.log('doingTasks');
          doingTasks.appendChild(finishedTasks.removeChild(element))     
          break;
      }
      ordenarDoingTasks();
})

pendingTasks.addEventListener('drop', (e) => {
    e.preventDefault()
    const element = document.getElementById(e.dataTransfer.getData('text'))
    element.classList.remove('active')
    const padre = element.parentNode.id
    switch (padre) {
        case 'doing-tasks':
          console.log('pendingTasks');
            let elementos = pendingTasks.getElementsByTagName("div");
            elementos = elementos[elementos.size - 1];
          pendingTasks.appendChild(doingTasks.removeChild(element))  
          break;
        case 'finished-tasks':
          console.log('doingTasks');
          pendingTasks.appendChild(finishedTasks.removeChild(element))     
          break;
      }
      ordenarPendingTasks();
})

doingTasks.addEventListener('dragstart', (e) => {
    console.log(e.dataTransfer)
    e.dataTransfer.setData('text/plain', e.target.id)
    console.log(e.dataTransfer.getData)
})

finishedTasks.addEventListener('dragstart', (e) => {
    console.log(e.dataTransfer)
    e.dataTransfer.setData('text/plain', e.target.id)
    console.log(e.dataTransfer.getData)
})

const ordenarDoingTasks = () => {
    let $wrapper = $('#doing-tasks');
    $wrapper.find('.ordenable').sort(function (a, b) {
        return a.dataset.name > b.dataset.name ? 1 : -1;
    })
    .appendTo($wrapper);
    console.log("ordenando");
}

const ordenarPendingTasks = () => {
    let $wrapper = $('#pending-tasks');
    $wrapper.find('.ordenable').sort(function (a, b) {
        return a.dataset.name > b.dataset.name ? 1 : -1;
    })
    .appendTo($wrapper);
    console.log("ordenando");
}

const ordenarFinishedTasks = () => {
    let $wrapper = $('#finished-tasks');
    $wrapper.find('.ordenable').sort(function (a, b) {
        return a.dataset.name > b.dataset.name ? 1 : -1;
    })
    .appendTo($wrapper);
    console.log("ordenando");
}