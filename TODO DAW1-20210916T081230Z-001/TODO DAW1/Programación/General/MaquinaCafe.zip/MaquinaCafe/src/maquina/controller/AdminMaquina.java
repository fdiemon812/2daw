package maquina.controller;
import java.io.IOException;
import java.sql.SQLException;


import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import maquina.Maquina;


@WebServlet("/adminMaquina")
public class AdminMaquina extends HttpServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	Maquina maquina;

	// Al inicializar, creo la máquina con el valor del monedero.
	public void init(double monedero) {
		maquina = new Maquina(monedero);
	}
	
	// El constructor llama a la clase de la que hereda
	public AdminMaquina() {
		super();
		// TODO Auto-generated constructor stub
	}

	// Esta es la función que se llama desde JSP y que gestiona el flujo
	// del programa. Cuando recive una palabra o token llama a un método
	// que realiza la ación.
	// En request se le pasa lo que llega del formulario
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String action = request.getParameter("action");
		try {
			switch (action) {
			case "empezar":
				empezar(request, response);
				break;
			case "cafe":
				cafe(request, response);
				break;		
			case "cambioCafe":
				cambioCafe(request, response);
				break;
			case "leche":
				leche(request, response);
				break;		
			case "cambioLeche":
				cambioLeche(request, response);
				break;
			case "cafeconleche":
				cafeconLeche(request, response);
				break;		
			case "cambioCafeconLeche":
				cambioCafeconLeche(request, response);
				break;
			case "llenar":
				llenarMaquina(request, response);
				break;	
			case "mostrar":
				mostrar(request, response);
				break;
			default:
				break;
			}			
		} catch (SQLException e) {
			e.getStackTrace();
		}
	}	
	
	// Llama a la clase padre.
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}
	
	// Cuando se pide un café llamado a la página que pide el dinero 
	// para el café
	
	private void cafe(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException, SQLException {
		RequestDispatcher dispatcher = request.getRequestDispatcher("pedircafe.jsp");
		dispatcher.forward(request, response);
	}
	
	// Igual para la leche
	
	private void leche(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException, SQLException {
		RequestDispatcher dispatcher = request.getRequestDispatcher("pedirleche.jsp");
		dispatcher.forward(request, response);
	}

	// Igual para el café con leche
	
	private void cafeconLeche(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException, SQLException {
		RequestDispatcher dispatcher = request.getRequestDispatcher("pedircafeconleche.jsp");
		dispatcher.forward(request, response);
	}
	
		
	private void empezar(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException, SQLException {
		// creo la máquina para empezar. El valor del monedero se pasa por parámetro
		maquina = new Maquina(Double.parseDouble(request.getParameter("monedero")));
				
		RequestDispatcher dispatcher = request.getRequestDispatcher("menu.jsp");
		
		request.setAttribute("depositoCafe",maquina.getDepositoCafe());
		request.setAttribute("depositoLeche", maquina.getDepositoLeche());
		request.setAttribute("depositoVasos", maquina.getDepositoVasos());
		dispatcher.forward(request, response);
	}
	
	// Cuando el usuario teclea el dinero que entrega vemos
	// si se puede devolver el dinero (si hay dinero suficiente)
	// en el monedro. Si no se puede devolver se manda un -2 para 
	// indicar el error. 
	
	private void cambioCafe(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException, SQLException {
			
		try {
				double cambio = maquina.servirCafe(Double.parseDouble(request.getParameter("dinero")));
				request.setAttribute("Cambio",cambio);
		} catch (Exception e) {
				// Significa que no se ha podido servir cafe. 
			request.setAttribute("noCambio",Double.parseDouble(request.getParameter("dinero")));
		}
		
		RequestDispatcher dispatcher = request.getRequestDispatcher("menu.jsp");
		
		request.setAttribute("depositoCafe",maquina.getDepositoCafe());
		request.setAttribute("depositoLeche", maquina.getDepositoLeche());
		request.setAttribute("depositoVasos", maquina.getDepositoVasos());
		
		dispatcher.forward(request, response);
	}
	
	// Igual para la leche
		
	private void cambioLeche(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException, SQLException {
		
	try {
			double cambio = maquina.servirLeche(Double.parseDouble(request.getParameter("dinero")));
			
			request.setAttribute("Cambio",(Math.round(cambio*100))/100.0);
	} catch (Exception e) {
			// Significa que no se ha podido servir leche. 
		request.setAttribute("noCambio",Double.parseDouble(request.getParameter("dinero")));
	}
	
	RequestDispatcher dispatcher = request.getRequestDispatcher("menu.jsp");
	
	request.setAttribute("depositoCafe",maquina.getDepositoCafe());
	request.setAttribute("depositoLeche", maquina.getDepositoLeche());
	request.setAttribute("depositoVasos", maquina.getDepositoVasos());
	
	dispatcher.forward(request, response);
	}
	
	// Igual para el café con leche
			
	private void cambioCafeconLeche(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException, SQLException {
		
		try {
			double cambio = maquina.servirCafeconLeche(Double.parseDouble(request.getParameter("dinero")));
			request.setAttribute("Cambio",cambio);
		} catch (Exception e) {
			// Significa que no se ha podido servir café con leche. 
			request.setAttribute("noCambio",Double.parseDouble(request.getParameter("dinero")));
		}
				
		RequestDispatcher dispatcher = request.getRequestDispatcher("menu.jsp");
		
		request.setAttribute("depositoCafe",maquina.getDepositoCafe());
		request.setAttribute("depositoLeche", maquina.getDepositoLeche());
		request.setAttribute("depositoVasos", maquina.getDepositoVasos()); 
		
		dispatcher.forward(request, response);
	}
	
	// Se llenan los depósitos y se manda al final un -1 para que 
	// no muestre el cambio.
	
	private void llenarMaquina(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException, SQLException {
		maquina.llenarDepositos();
		RequestDispatcher dispatcher = request.getRequestDispatcher("menu.jsp");
		
		request.setAttribute("depositoCafe",maquina.getDepositoCafe());
		request.setAttribute("depositoLeche", maquina.getDepositoLeche());
		request.setAttribute("depositoVasos", maquina.getDepositoVasos());
		dispatcher.forward(request, response);
	}
	
	// Mando los depósitos y el valor de la máquina para mostrarlo
	
	private void mostrar(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException, SQLException {
		
		RequestDispatcher dispatcher = request.getRequestDispatcher("menu.jsp");
		
		request.setAttribute("depositoCafe",maquina.getDepositoCafe());
		request.setAttribute("depositoLeche", maquina.getDepositoLeche());
		request.setAttribute("depositoVasos", maquina.getDepositoVasos());
		request.setAttribute("monedero", maquina.getMonedero());
		dispatcher.forward(request, response);
	}
	
	

}
